

Figs 1-3 default
Fig 4-5 1 action potential (Austin, each AP 0.23msec, 4mM pulse)
Fig 6-7 3 action potentials (Austin, 4mM)
Fig 8-9 10 action potentials (Austin, 4mM)
Fig 10-15 1,3, and 10 action potentials (Reduced, 0.5mM)

