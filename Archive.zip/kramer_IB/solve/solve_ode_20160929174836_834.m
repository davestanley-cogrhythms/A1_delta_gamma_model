function [T,IB_V,IB_IBiNaF_hNaF,IB_IBiKDR_mKDR,IB_IBiMMich_mM,IB_IBiCaH_mCaH,NG_V,NG_FSiNaF_hNaF,NG_FSiKDR_mKDR,NG_iAhuguenard_a1,NG_iAhuguenard_b1,NG_iAhuguenard_a2,NG_iAhuguenard_b2,IB_IB_IBaIBdbiSYNseed_s,IB_IB_iNMDA_s,NG_IB_IBaIBdbiSYNseed_s,NG_IB_iNMDA_s,NG_NG_IBaIBdbiSYNseed_s,NG_NG_iGABABAustin_r,NG_NG_iGABABAustin_g,IB_NG_IBaIBdbiSYNseed_s,IB_NG_iGABABAustin_r,IB_NG_iGABABAustin_g,NG_NG_iGABABAustin_IGABAB,IB_NG_iGABABAustin_IGABAB,IB_IB_IBaIBdbiSYNseed_ISYN,IB_IB_iNMDA_BMg,IB_IB_iNMDA_INMDA,IB_IB_iNMDA_NT,IB_NG_IBaIBdbiSYNseed_ISYN,IB_iPeriodicPulses_Iext,NG_IB_IBaIBdbiSYNseed_ISYN,NG_IB_iNMDA_BMg,NG_IB_iNMDA_INMDA,NG_IB_iNMDA_NT,NG_NG_IBaIBdbiSYNseed_ISYN,NG_iAhuguenard_IA,NG_iAhuguenard_a1inf,NG_iAhuguenard_a1tau,NG_iAhuguenard_a2inf,NG_iAhuguenard_b1inf,NG_iAhuguenard_b1tau,NG_iAhuguenard_b2tau,NG_iPeriodicPulses_Iext,IB_iPeriodicPulses_Tend,IB_iPeriodicPulses_s2,IB_IBdbiPoissonExpJason_T2,IB_IBdbiPoissonExpJason_s,NG_iPeriodicPulses_Tend,NG_iPeriodicPulses_s2,IB_IB_IBaIBdbiSYNseed_UB,IB_IB_IBaIBdbiSYNseed_Xpre,IB_IB_IBaIBdbiSYNseed_Xpost,IB_IB_IBaIBdbiSYNseed_mask,IB_IB_IBaIBdbiSYNseed_gsyn,IB_IB_iNMDA_netcon,IB_IB_IBaIBaiGAP_UB,IB_IB_IBaIBaiGAP_Xpre,IB_IB_IBaIBaiGAP_Xpost,IB_IB_IBaIBaiGAP_mask,NG_IB_IBaIBdbiSYNseed_UB,NG_IB_IBaIBdbiSYNseed_Xpre,NG_IB_IBaIBdbiSYNseed_Xpost,NG_IB_IBaIBdbiSYNseed_mask,NG_IB_IBaIBdbiSYNseed_gsyn,NG_IB_iNMDA_netcon,NG_NG_IBaIBdbiSYNseed_UB,NG_NG_IBaIBdbiSYNseed_Xpre,NG_NG_IBaIBdbiSYNseed_Xpost,NG_NG_IBaIBdbiSYNseed_mask,NG_NG_IBaIBdbiSYNseed_gsyn,NG_NG_iGABABAustin_Nmax,NG_NG_iGABABAustin_srcpos,NG_NG_iGABABAustin_dstpos,NG_NG_iGABABAustin_netcon,IB_NG_IBaIBdbiSYNseed_UB,IB_NG_IBaIBdbiSYNseed_Xpre,IB_NG_IBaIBdbiSYNseed_Xpost,IB_NG_IBaIBdbiSYNseed_mask,IB_NG_IBaIBdbiSYNseed_gsyn,IB_NG_iGABABAustin_Nmax,IB_NG_iGABABAustin_srcpos,IB_NG_iGABABAustin_dstpos,IB_NG_iGABABAustin_netcon]=solve_ode
% ------------------------------------------------------------
% Parameters:
% ------------------------------------------------------------
p=load('params.mat','p'); p=p.p;
downsample_factor=p.downsample_factor;
dt=p.dt;
T=(p.tspan(1):dt:p.tspan(2))';
ntime=length(T);
nsamp=length(1:downsample_factor:ntime);
% ------------------------------------------------------------
% Fixed variables:
% ------------------------------------------------------------
IB_iPeriodicPulses_Tend = T(end);
IB_iPeriodicPulses_s2 = getAperiodicPulseFast(p.IB_iPeriodicPulses_PPfreq,p.IB_iPeriodicPulses_PPwidth,p.IB_iPeriodicPulses_PPshift,IB_iPeriodicPulses_Tend,p.IB_iPeriodicPulses_dt,p.IB_iPeriodicPulses_PPonset,p.IB_iPeriodicPulses_PPoffset,p.IB_iPeriodicPulses_ap_pulse_num,p.IB_iPeriodicPulses_ap_pulse_delay,p.IB_Npop,p.IB_iPeriodicPulses_kernel_type,p.IB_iPeriodicPulses_width2_rise);
IB_IBdbiPoissonExpJason_T2 = (0:0.01:p.IB_IBdbiPoissonExpJason_T)';
IB_IBdbiPoissonExpJason_s = getPoissonGating(p.IB_IBdbiPoissonExpJason_baseline,p.IB_IBdbiPoissonExpJason_lambda,p.IB_IBdbiPoissonExpJason_ac,p.IB_IBdbiPoissonExpJason_freq,p.IB_IBdbiPoissonExpJason_phase,p.IB_IBdbiPoissonExpJason_onsetRAN,p.IB_IBdbiPoissonExpJason_T,p.IB_IBdbiPoissonExpJason_tauRAN,IB_IBdbiPoissonExpJason_T2,p.IB_Npop);
NG_iPeriodicPulses_Tend = T(end);
NG_iPeriodicPulses_s2 = getAperiodicPulseFast(p.NG_iPeriodicPulses_PPfreq,p.NG_iPeriodicPulses_PPwidth,p.NG_iPeriodicPulses_PPshift,NG_iPeriodicPulses_Tend,p.NG_iPeriodicPulses_dt,p.NG_iPeriodicPulses_PPonset,p.NG_iPeriodicPulses_PPoffset,p.NG_iPeriodicPulses_ap_pulse_num,p.NG_iPeriodicPulses_ap_pulse_delay,p.NG_Npop,p.NG_iPeriodicPulses_kernel_type,p.NG_iPeriodicPulses_width2_rise);
IB_IB_IBaIBdbiSYNseed_UB =  max(p.IB_Npop,p.IB_Npop);
IB_IB_IBaIBdbiSYNseed_Xpre =  linspace(1,IB_IB_IBaIBdbiSYNseed_UB,p.IB_Npop)'*ones(1,p.IB_Npop);
IB_IB_IBaIBdbiSYNseed_Xpost =  (linspace(1,IB_IB_IBaIBdbiSYNseed_UB,p.IB_Npop)'*ones(1,p.IB_Npop))';
IB_IB_IBaIBdbiSYNseed_mask =  (abs(IB_IB_IBaIBdbiSYNseed_Xpre-IB_IB_IBaIBdbiSYNseed_Xpost)<=p.IB_IB_IBaIBdbiSYNseed_fanout);
IB_IB_IBaIBdbiSYNseed_gsyn = unifrnd(p.IB_IB_IBaIBdbiSYNseed_g_SYN-p.IB_IB_IBaIBdbiSYNseed_g_SYN_hetero,p.IB_IB_IBaIBdbiSYNseed_g_SYN+p.IB_IB_IBaIBdbiSYNseed_g_SYN_hetero,[p.IB_Npop 1])';
IB_IB_iNMDA_netcon =  ones(p.IB_Npop,p.IB_Npop);
IB_IB_IBaIBaiGAP_UB =  max(p.IB_Npop,p.IB_Npop);
IB_IB_IBaIBaiGAP_Xpre =  linspace(1,IB_IB_IBaIBaiGAP_UB,p.IB_Npop)'*ones(1,p.IB_Npop);
IB_IB_IBaIBaiGAP_Xpost =  (linspace(1,IB_IB_IBaIBaiGAP_UB,p.IB_Npop)'*ones(1,p.IB_Npop))';
IB_IB_IBaIBaiGAP_mask =  abs(IB_IB_IBaIBaiGAP_Xpre-IB_IB_IBaIBaiGAP_Xpost)<=p.IB_IB_IBaIBaiGAP_fanout;
NG_IB_IBaIBdbiSYNseed_UB =  max(p.IB_Npop,p.NG_Npop);
NG_IB_IBaIBdbiSYNseed_Xpre =  linspace(1,NG_IB_IBaIBdbiSYNseed_UB,p.IB_Npop)'*ones(1,p.NG_Npop);
NG_IB_IBaIBdbiSYNseed_Xpost =  (linspace(1,NG_IB_IBaIBdbiSYNseed_UB,p.NG_Npop)'*ones(1,p.IB_Npop))';
NG_IB_IBaIBdbiSYNseed_mask =  (abs(NG_IB_IBaIBdbiSYNseed_Xpre-NG_IB_IBaIBdbiSYNseed_Xpost)<=p.NG_IB_IBaIBdbiSYNseed_fanout);
NG_IB_IBaIBdbiSYNseed_gsyn = unifrnd(p.NG_IB_IBaIBdbiSYNseed_g_SYN-p.NG_IB_IBaIBdbiSYNseed_g_SYN_hetero,p.NG_IB_IBaIBdbiSYNseed_g_SYN+p.NG_IB_IBaIBdbiSYNseed_g_SYN_hetero,[p.NG_Npop 1])';
NG_IB_iNMDA_netcon =  ones(p.IB_Npop,p.NG_Npop);
NG_NG_IBaIBdbiSYNseed_UB =  max(p.NG_Npop,p.NG_Npop);
NG_NG_IBaIBdbiSYNseed_Xpre =  linspace(1,NG_NG_IBaIBdbiSYNseed_UB,p.NG_Npop)'*ones(1,p.NG_Npop);
NG_NG_IBaIBdbiSYNseed_Xpost =  (linspace(1,NG_NG_IBaIBdbiSYNseed_UB,p.NG_Npop)'*ones(1,p.NG_Npop))';
NG_NG_IBaIBdbiSYNseed_mask =  (abs(NG_NG_IBaIBdbiSYNseed_Xpre-NG_NG_IBaIBdbiSYNseed_Xpost)<=p.NG_NG_IBaIBdbiSYNseed_fanout);
NG_NG_IBaIBdbiSYNseed_gsyn = unifrnd(p.NG_NG_IBaIBdbiSYNseed_g_SYN-p.NG_NG_IBaIBdbiSYNseed_g_SYN_hetero,p.NG_NG_IBaIBdbiSYNseed_g_SYN+p.NG_NG_IBaIBdbiSYNseed_g_SYN_hetero,[p.NG_Npop 1])';
NG_NG_iGABABAustin_Nmax =  max(p.NG_Npop,p.NG_Npop);
NG_NG_iGABABAustin_srcpos =  linspace(1,NG_NG_iGABABAustin_Nmax,p.NG_Npop)'*ones(1,p.NG_Npop);
NG_NG_iGABABAustin_dstpos =  (linspace(1,NG_NG_iGABABAustin_Nmax,p.NG_Npop)'*ones(1,p.NG_Npop))';
NG_NG_iGABABAustin_netcon =  (abs(NG_NG_iGABABAustin_srcpos-NG_NG_iGABABAustin_dstpos)<=p.NG_NG_iGABABAustin_width);
IB_NG_IBaIBdbiSYNseed_UB =  max(p.NG_Npop,p.IB_Npop);
IB_NG_IBaIBdbiSYNseed_Xpre =  linspace(1,IB_NG_IBaIBdbiSYNseed_UB,p.NG_Npop)'*ones(1,p.IB_Npop);
IB_NG_IBaIBdbiSYNseed_Xpost =  (linspace(1,IB_NG_IBaIBdbiSYNseed_UB,p.IB_Npop)'*ones(1,p.NG_Npop))';
IB_NG_IBaIBdbiSYNseed_mask =  (abs(IB_NG_IBaIBdbiSYNseed_Xpre-IB_NG_IBaIBdbiSYNseed_Xpost)<=p.IB_NG_IBaIBdbiSYNseed_fanout);
IB_NG_IBaIBdbiSYNseed_gsyn = unifrnd(p.IB_NG_IBaIBdbiSYNseed_g_SYN-p.IB_NG_IBaIBdbiSYNseed_g_SYN_hetero,p.IB_NG_IBaIBdbiSYNseed_g_SYN+p.IB_NG_IBaIBdbiSYNseed_g_SYN_hetero,[p.IB_Npop 1])';
IB_NG_iGABABAustin_Nmax =  max(p.NG_Npop,p.IB_Npop);
IB_NG_iGABABAustin_srcpos =  linspace(1,IB_NG_iGABABAustin_Nmax,p.NG_Npop)'*ones(1,p.IB_Npop);
IB_NG_iGABABAustin_dstpos =  (linspace(1,IB_NG_iGABABAustin_Nmax,p.IB_Npop)'*ones(1,p.NG_Npop))';
IB_NG_iGABABAustin_netcon =  (abs(IB_NG_iGABABAustin_srcpos-IB_NG_iGABABAustin_dstpos)<=p.IB_NG_iGABABAustin_width);
% ------------------------------------------------------------
% Initial conditions:
% ------------------------------------------------------------
% seed the random number generator
rng(p.random_seed);
t=0; k=1;
% STATE_VARIABLES:
IB_V_last = -65*ones(1,p.IB_Npop);
IB_V = zeros(nsamp,p.IB_Npop);
  IB_V(1,:) = IB_V_last;
IB_IBiNaF_hNaF_last =  p.IB_IBiNaF_IC+p.IB_IBiNaF_IC_noise.*rand(1,p.IB_Npop);
IB_IBiNaF_hNaF = zeros(nsamp,p.IB_Npop);
  IB_IBiNaF_hNaF(1,:) = IB_IBiNaF_hNaF_last;
IB_IBiKDR_mKDR_last =  p.IB_IBiKDR_IC+p.IB_IBiKDR_IC_noise.*rand(1,p.IB_Npop);
IB_IBiKDR_mKDR = zeros(nsamp,p.IB_Npop);
  IB_IBiKDR_mKDR(1,:) = IB_IBiKDR_mKDR_last;
IB_IBiMMich_mM_last =  p.IB_IBiMMich_IC+p.IB_IBiMMich_IC_noise.*rand(1,p.IB_Npop);
IB_IBiMMich_mM = zeros(nsamp,p.IB_Npop);
  IB_IBiMMich_mM(1,:) = IB_IBiMMich_mM_last;
IB_IBiCaH_mCaH_last =  p.IB_IBiCaH_IC+p.IB_IBiCaH_IC_noise.*rand(1,p.IB_Npop);
IB_IBiCaH_mCaH = zeros(nsamp,p.IB_Npop);
  IB_IBiCaH_mCaH(1,:) = IB_IBiCaH_mCaH_last;
NG_V_last = -65*ones(1,p.NG_Npop);
NG_V = zeros(nsamp,p.NG_Npop);
  NG_V(1,:) = NG_V_last;
NG_FSiNaF_hNaF_last =  p.NG_FSiNaF_IC+p.NG_FSiNaF_IC_noise.*rand(1,p.NG_Npop);
NG_FSiNaF_hNaF = zeros(nsamp,p.NG_Npop);
  NG_FSiNaF_hNaF(1,:) = NG_FSiNaF_hNaF_last;
NG_FSiKDR_mKDR_last =  p.NG_FSiKDR_IC+p.NG_FSiKDR_IC_noise.*rand(1,p.NG_Npop);
NG_FSiKDR_mKDR = zeros(nsamp,p.NG_Npop);
  NG_FSiKDR_mKDR(1,:) = NG_FSiKDR_mKDR_last;
NG_iAhuguenard_a1_last =  p.NG_iAhuguenard_IC+p.NG_iAhuguenard_IC_noise.*rand(1,p.NG_Npop);
NG_iAhuguenard_a1 = zeros(nsamp,p.NG_Npop);
  NG_iAhuguenard_a1(1,:) = NG_iAhuguenard_a1_last;
NG_iAhuguenard_b1_last =  p.NG_iAhuguenard_IC+p.NG_iAhuguenard_IC_noise.*rand(1,p.NG_Npop);
NG_iAhuguenard_b1 = zeros(nsamp,p.NG_Npop);
  NG_iAhuguenard_b1(1,:) = NG_iAhuguenard_b1_last;
NG_iAhuguenard_a2_last =  p.NG_iAhuguenard_IC+p.NG_iAhuguenard_IC_noise.*rand(1,p.NG_Npop);
NG_iAhuguenard_a2 = zeros(nsamp,p.NG_Npop);
  NG_iAhuguenard_a2(1,:) = NG_iAhuguenard_a2_last;
NG_iAhuguenard_b2_last =  p.NG_iAhuguenard_IC+p.NG_iAhuguenard_IC_noise.*rand(1,p.NG_Npop);
NG_iAhuguenard_b2 = zeros(nsamp,p.NG_Npop);
  NG_iAhuguenard_b2(1,:) = NG_iAhuguenard_b2_last;
IB_IB_IBaIBdbiSYNseed_s_last =  p.IB_IB_IBaIBdbiSYNseed_IC+p.IB_IB_IBaIBdbiSYNseed_IC_noise.*rand(1,p.IB_Npop)';
IB_IB_IBaIBdbiSYNseed_s = zeros(nsamp,p.IB_Npop);
  IB_IB_IBaIBdbiSYNseed_s(1,:) = IB_IB_IBaIBdbiSYNseed_s_last;
IB_IB_iNMDA_s_last =  p.IB_IB_iNMDA_IC+p.IB_IB_iNMDA_IC_noise*rand(1,p.IB_Npop);
IB_IB_iNMDA_s = zeros(nsamp,p.IB_Npop);
  IB_IB_iNMDA_s(1,:) = IB_IB_iNMDA_s_last;
NG_IB_IBaIBdbiSYNseed_s_last =  p.NG_IB_IBaIBdbiSYNseed_IC+p.NG_IB_IBaIBdbiSYNseed_IC_noise.*rand(1,p.IB_Npop)';
NG_IB_IBaIBdbiSYNseed_s = zeros(nsamp,p.IB_Npop);
  NG_IB_IBaIBdbiSYNseed_s(1,:) = NG_IB_IBaIBdbiSYNseed_s_last;
NG_IB_iNMDA_s_last =  p.NG_IB_iNMDA_IC+p.NG_IB_iNMDA_IC_noise*rand(1,p.IB_Npop);
NG_IB_iNMDA_s = zeros(nsamp,p.IB_Npop);
  NG_IB_iNMDA_s(1,:) = NG_IB_iNMDA_s_last;
NG_NG_IBaIBdbiSYNseed_s_last =  p.NG_NG_IBaIBdbiSYNseed_IC+p.NG_NG_IBaIBdbiSYNseed_IC_noise.*rand(1,p.NG_Npop)';
NG_NG_IBaIBdbiSYNseed_s = zeros(nsamp,p.NG_Npop);
  NG_NG_IBaIBdbiSYNseed_s(1,:) = NG_NG_IBaIBdbiSYNseed_s_last;
NG_NG_iGABABAustin_r_last =  p.NG_NG_iGABABAustin_IC+p.NG_NG_iGABABAustin_IC_noise.*rand(1,p.NG_Npop)';
NG_NG_iGABABAustin_r = zeros(nsamp,p.NG_Npop);
  NG_NG_iGABABAustin_r(1,:) = NG_NG_iGABABAustin_r_last;
NG_NG_iGABABAustin_g_last =  p.NG_NG_iGABABAustin_IC+p.NG_NG_iGABABAustin_IC_noise.*rand(1,p.NG_Npop)';
NG_NG_iGABABAustin_g = zeros(nsamp,p.NG_Npop);
  NG_NG_iGABABAustin_g(1,:) = NG_NG_iGABABAustin_g_last;
IB_NG_IBaIBdbiSYNseed_s_last =  p.IB_NG_IBaIBdbiSYNseed_IC+p.IB_NG_IBaIBdbiSYNseed_IC_noise.*rand(1,p.NG_Npop)';
IB_NG_IBaIBdbiSYNseed_s = zeros(nsamp,p.NG_Npop);
  IB_NG_IBaIBdbiSYNseed_s(1,:) = IB_NG_IBaIBdbiSYNseed_s_last;
IB_NG_iGABABAustin_r_last =  p.IB_NG_iGABABAustin_IC+p.IB_NG_iGABABAustin_IC_noise.*rand(1,p.NG_Npop)';
IB_NG_iGABABAustin_r = zeros(nsamp,p.NG_Npop);
  IB_NG_iGABABAustin_r(1,:) = IB_NG_iGABABAustin_r_last;
IB_NG_iGABABAustin_g_last =  p.IB_NG_iGABABAustin_IC+p.IB_NG_iGABABAustin_IC_noise.*rand(1,p.NG_Npop)';
IB_NG_iGABABAustin_g = zeros(nsamp,p.NG_Npop);
  IB_NG_iGABABAustin_g(1,:) = IB_NG_iGABABAustin_g_last;
% MONITORS:
  NG_NG_iGABABAustin_IGABAB_last=p.NG_NG_iGABABAustin_gGABAB.*((NG_NG_iGABABAustin_g_last.^4./(NG_NG_iGABABAustin_g_last.^4 + 100))*NG_NG_iGABABAustin_netcon).*(NG_V_last-p.NG_NG_iGABABAustin_EGABAB);
NG_NG_iGABABAustin_IGABAB = zeros(nsamp,p.NG_Npop);
  NG_NG_iGABABAustin_IGABAB(1,:)=p.NG_NG_iGABABAustin_gGABAB.*((NG_NG_iGABABAustin_g(1,:).^4./(NG_NG_iGABABAustin_g(1,:).^4 + 100))*NG_NG_iGABABAustin_netcon).*(NG_V(1,:)-p.NG_NG_iGABABAustin_EGABAB);
  IB_NG_iGABABAustin_IGABAB_last=p.IB_NG_iGABABAustin_gGABAB.*((IB_NG_iGABABAustin_g_last.^4./(IB_NG_iGABABAustin_g_last.^4 + 100))*IB_NG_iGABABAustin_netcon).*(IB_V_last-p.IB_NG_iGABABAustin_EGABAB);
IB_NG_iGABABAustin_IGABAB = zeros(nsamp,p.IB_Npop);
  IB_NG_iGABABAustin_IGABAB(1,:)=p.IB_NG_iGABABAustin_gGABAB.*((IB_NG_iGABABAustin_g(1,:).^4./(IB_NG_iGABABAustin_g(1,:).^4 + 100))*IB_NG_iGABABAustin_netcon).*(IB_V(1,:)-p.IB_NG_iGABABAustin_EGABAB);
  IB_IB_IBaIBdbiSYNseed_ISYN_last=(IB_IB_IBaIBdbiSYNseed_gsyn.*(IB_IB_IBaIBdbiSYNseed_s_last*IB_IB_IBaIBdbiSYNseed_mask).*(IB_V_last-p.IB_IB_IBaIBdbiSYNseed_E_SYN));
IB_IB_IBaIBdbiSYNseed_ISYN = zeros(nsamp,p.IB_Npop);
  IB_IB_IBaIBdbiSYNseed_ISYN(1,:)=(IB_IB_IBaIBdbiSYNseed_gsyn.*(IB_IB_IBaIBdbiSYNseed_s(1,:)*IB_IB_IBaIBdbiSYNseed_mask).*(IB_V(1,:)-p.IB_IB_IBaIBdbiSYNseed_E_SYN));
  IB_IB_iNMDA_BMg_last=1./(1+exp(-.062*IB_V_last)*1.5/3.57);
IB_IB_iNMDA_BMg = zeros(nsamp,p.IB_Npop);
  IB_IB_iNMDA_BMg(1,:)=1./(1+exp(-.062*IB_V(1,:))*1.5/3.57);
  IB_IB_iNMDA_INMDA_last=p.IB_IB_iNMDA_gNMDA.*(( 1./(1+exp(-.062*IB_V_last)*1.5/3.57))).*(IB_IB_iNMDA_s_last*IB_IB_iNMDA_netcon).*(IB_V_last-p.IB_IB_iNMDA_ENMDA);
IB_IB_iNMDA_INMDA = zeros(nsamp,p.IB_Npop);
  IB_IB_iNMDA_INMDA(1,:)=p.IB_IB_iNMDA_gNMDA.*(( 1./(1+exp(-.062*IB_V(1,:))*1.5/3.57))).*(IB_IB_iNMDA_s(1,:)*IB_IB_iNMDA_netcon).*(IB_V(1,:)-p.IB_IB_iNMDA_ENMDA);
  IB_IB_iNMDA_NT_last=p.IB_IB_iNMDA_Tmax./(1+exp(-(IB_V_last-p.IB_IB_iNMDA_Vpp)/p.IB_IB_iNMDA_Kp));
IB_IB_iNMDA_NT = zeros(nsamp,p.IB_Npop);
  IB_IB_iNMDA_NT(1,:)=p.IB_IB_iNMDA_Tmax./(1+exp(-(IB_V(1,:)-p.IB_IB_iNMDA_Vpp)/p.IB_IB_iNMDA_Kp));
  IB_NG_IBaIBdbiSYNseed_ISYN_last=(IB_NG_IBaIBdbiSYNseed_gsyn.*(IB_NG_IBaIBdbiSYNseed_s_last*IB_NG_IBaIBdbiSYNseed_mask).*(IB_V_last-p.IB_NG_IBaIBdbiSYNseed_E_SYN));
IB_NG_IBaIBdbiSYNseed_ISYN = zeros(nsamp,p.IB_Npop);
  IB_NG_IBaIBdbiSYNseed_ISYN(1,:)=(IB_NG_IBaIBdbiSYNseed_gsyn.*(IB_NG_IBaIBdbiSYNseed_s(1,:)*IB_NG_IBaIBdbiSYNseed_mask).*(IB_V(1,:)-p.IB_NG_IBaIBdbiSYNseed_E_SYN));
  IB_iPeriodicPulses_Iext_last=p.IB_iPeriodicPulses_PPstim*IB_iPeriodicPulses_s2(k,:);
IB_iPeriodicPulses_Iext = zeros(nsamp,p.IB_Npop);
  IB_iPeriodicPulses_Iext(1,:)=p.IB_iPeriodicPulses_PPstim*IB_iPeriodicPulses_s2(k,:);
  NG_IB_IBaIBdbiSYNseed_ISYN_last=(NG_IB_IBaIBdbiSYNseed_gsyn.*(NG_IB_IBaIBdbiSYNseed_s_last*NG_IB_IBaIBdbiSYNseed_mask).*(NG_V_last-p.NG_IB_IBaIBdbiSYNseed_E_SYN));
NG_IB_IBaIBdbiSYNseed_ISYN = zeros(nsamp,p.NG_Npop);
  NG_IB_IBaIBdbiSYNseed_ISYN(1,:)=(NG_IB_IBaIBdbiSYNseed_gsyn.*(NG_IB_IBaIBdbiSYNseed_s(1,:)*NG_IB_IBaIBdbiSYNseed_mask).*(NG_V(1,:)-p.NG_IB_IBaIBdbiSYNseed_E_SYN));
  NG_IB_iNMDA_BMg_last=1./(1+exp(-.062*NG_V_last)*1.5/3.57);
NG_IB_iNMDA_BMg = zeros(nsamp,p.NG_Npop);
  NG_IB_iNMDA_BMg(1,:)=1./(1+exp(-.062*NG_V(1,:))*1.5/3.57);
  NG_IB_iNMDA_INMDA_last=p.NG_IB_iNMDA_gNMDA.*(( 1./(1+exp(-.062*NG_V_last)*1.5/3.57))).*(NG_IB_iNMDA_s_last*NG_IB_iNMDA_netcon).*(NG_V_last-p.NG_IB_iNMDA_ENMDA);
NG_IB_iNMDA_INMDA = zeros(nsamp,p.NG_Npop);
  NG_IB_iNMDA_INMDA(1,:)=p.NG_IB_iNMDA_gNMDA.*(( 1./(1+exp(-.062*NG_V(1,:))*1.5/3.57))).*(NG_IB_iNMDA_s(1,:)*NG_IB_iNMDA_netcon).*(NG_V(1,:)-p.NG_IB_iNMDA_ENMDA);
  NG_IB_iNMDA_NT_last=p.NG_IB_iNMDA_Tmax./(1+exp(-(NG_V_last-p.NG_IB_iNMDA_Vpp)/p.NG_IB_iNMDA_Kp));
NG_IB_iNMDA_NT = zeros(nsamp,p.NG_Npop);
  NG_IB_iNMDA_NT(1,:)=p.NG_IB_iNMDA_Tmax./(1+exp(-(NG_V(1,:)-p.NG_IB_iNMDA_Vpp)/p.NG_IB_iNMDA_Kp));
  NG_NG_IBaIBdbiSYNseed_ISYN_last=(NG_NG_IBaIBdbiSYNseed_gsyn.*(NG_NG_IBaIBdbiSYNseed_s_last*NG_NG_IBaIBdbiSYNseed_mask).*(NG_V_last-p.NG_NG_IBaIBdbiSYNseed_E_SYN));
NG_NG_IBaIBdbiSYNseed_ISYN = zeros(nsamp,p.NG_Npop);
  NG_NG_IBaIBdbiSYNseed_ISYN(1,:)=(NG_NG_IBaIBdbiSYNseed_gsyn.*(NG_NG_IBaIBdbiSYNseed_s(1,:)*NG_NG_IBaIBdbiSYNseed_mask).*(NG_V(1,:)-p.NG_NG_IBaIBdbiSYNseed_E_SYN));
  NG_iAhuguenard_IA_last=p.NG_iAhuguenard_gA * ( p.NG_iAhuguenard_iA1_fract*(NG_iAhuguenard_a1_last.^4 .* NG_iAhuguenard_b1_last) + (1-p.NG_iAhuguenard_iA1_fract)*(NG_iAhuguenard_a2_last.^4 .* NG_iAhuguenard_b2_last) ) .* (NG_V_last-p.NG_iAhuguenard_E_A);
NG_iAhuguenard_IA = zeros(nsamp,p.NG_Npop);
  NG_iAhuguenard_IA(1,:)=p.NG_iAhuguenard_gA * ( p.NG_iAhuguenard_iA1_fract*(NG_iAhuguenard_a1(1,:).^4 .* NG_iAhuguenard_b1(1,:)) + (1-p.NG_iAhuguenard_iA1_fract)*(NG_iAhuguenard_a2(1,:).^4 .* NG_iAhuguenard_b2(1,:)) ) .* (NG_V(1,:)-p.NG_iAhuguenard_E_A);
  NG_iAhuguenard_a1inf_last=1./(1+exp(-(NG_V_last+60)/8.5));
NG_iAhuguenard_a1inf = zeros(nsamp,p.NG_Npop);
  NG_iAhuguenard_a1inf(1,:)=1./(1+exp(-(NG_V(1,:)+60)/8.5));
  NG_iAhuguenard_a1tau_last=.37+1./(exp((NG_V_last+35.8)/19.7)+exp((NG_V_last+79.7)/-12.7));
NG_iAhuguenard_a1tau = zeros(nsamp,p.NG_Npop);
  NG_iAhuguenard_a1tau(1,:)=.37+1./(exp((NG_V(1,:)+35.8)/19.7)+exp((NG_V(1,:)+79.7)/-12.7));
  NG_iAhuguenard_a2inf_last=1./(1+exp(-(NG_V_last+36)/20));
NG_iAhuguenard_a2inf = zeros(nsamp,p.NG_Npop);
  NG_iAhuguenard_a2inf(1,:)=1./(1+exp(-(NG_V(1,:)+36)/20));
  NG_iAhuguenard_b1inf_last=1./(1+exp((NG_V_last+78)/6));
NG_iAhuguenard_b1inf = zeros(nsamp,p.NG_Npop);
  NG_iAhuguenard_b1inf(1,:)=1./(1+exp((NG_V(1,:)+78)/6));
  NG_iAhuguenard_b1tau_last=(1./(exp((NG_V_last+46)/5)+exp((NG_V_last+238)/(-37.5)))) .* (NG_V_last<-63) + 19 * (NG_V_last>=-63);
NG_iAhuguenard_b1tau = zeros(nsamp,p.NG_Npop);
  NG_iAhuguenard_b1tau(1,:)=(1./(exp((NG_V(1,:)+46)/5)+exp((NG_V(1,:)+238)/(-37.5)))) .* (NG_V(1,:)<-63) + 19 * (NG_V(1,:)>=-63);
  NG_iAhuguenard_b2tau_last=(((1./(exp((NG_V_last+46)/5)+exp((NG_V_last+238)/(-37.5)))) .* (NG_V_last<-63) + 19 * (NG_V_last>=-63))) .* (NG_V_last<-73) + 60 * (NG_V_last>=-73);
NG_iAhuguenard_b2tau = zeros(nsamp,p.NG_Npop);
  NG_iAhuguenard_b2tau(1,:)=(((1./(exp((NG_V(1,:)+46)/5)+exp((NG_V(1,:)+238)/(-37.5)))) .* (NG_V(1,:)<-63) + 19 * (NG_V(1,:)>=-63))) .* (NG_V(1,:)<-73) + 60 * (NG_V(1,:)>=-73);
  NG_iPeriodicPulses_Iext_last=p.NG_iPeriodicPulses_PPstim*NG_iPeriodicPulses_s2(k,:);
NG_iPeriodicPulses_Iext = zeros(nsamp,p.NG_Npop);
  NG_iPeriodicPulses_Iext(1,:)=p.NG_iPeriodicPulses_PPstim*NG_iPeriodicPulses_s2(k,:);
% ###########################################################
% Numerical integration:
% ###########################################################
n=2;
for k=2:ntime
  t=T(k-1);
  IB_V_k1=(((-((p.IB_iPeriodicPulses_PPstim*IB_iPeriodicPulses_s2(k,:))))+((-((p.IB_IBdbiPoissonExpJason_gRAN*IB_IBdbiPoissonExpJason_s(k,:).*(IB_V_last-p.IB_IBdbiPoissonExpJason_ERAN))))+((-(( p.IB_itonicPaired_stim*(t>p.IB_itonicPaired_onset & t<p.IB_itonicPaired_offset) + p.IB_itonicPaired_stim2*(t>p.IB_itonicPaired_onset2 & t<p.IB_itonicPaired_offset2))))+((p.IB_IBnoise_V_noise.*randn(1,p.IB_Npop))+((-(( p.IB_IBiNaF_gNaF.*(( 1./(1+exp((-IB_V_last-p.IB_IBiNaF_NaF_V0)/10)))).^3.*IB_IBiNaF_hNaF_last.*(IB_V_last-p.IB_IBiNaF_E_NaF))))+((-(( p.IB_IBiKDR_gKDR.*IB_IBiKDR_mKDR_last.^4.*(IB_V_last-p.IB_IBiKDR_E_KDR))))+((-(( p.IB_IBiMMich_gM.*IB_IBiMMich_mM_last.*(IB_V_last-p.IB_IBiMMich_E_M))))+((-(( p.IB_IBiCaH_gCaH.*IB_IBiCaH_mCaH_last.^2.*(IB_V_last-p.IB_IBiCaH_E_CaH))))+((-(( p.IB_IBleak_g_l.*(IB_V_last-p.IB_IBleak_E_l))))+((-(( (IB_IB_IBaIBdbiSYNseed_gsyn.*(IB_IB_IBaIBdbiSYNseed_s_last*IB_IB_IBaIBdbiSYNseed_mask).*(IB_V_last-p.IB_IB_IBaIBdbiSYNseed_E_SYN)))))+((-(( p.IB_IB_iNMDA_gNMDA.*(( 1./(1+exp(-.062*IB_V_last)*1.5/3.57))).*(IB_IB_iNMDA_s_last*IB_IB_iNMDA_netcon).*(IB_V_last-p.IB_IB_iNMDA_ENMDA))))+(((( p.IB_IB_IBaIBaiGAP_g_GAP.*sum(((IB_V_last'*ones(1,size(IB_V_last',1)))'-(IB_V_last'*ones(1,size(IB_V_last',1)))).*IB_IB_IBaIBaiGAP_mask,2)')))+((-(( (IB_NG_IBaIBdbiSYNseed_gsyn.*(IB_NG_IBaIBdbiSYNseed_s_last*IB_NG_IBaIBdbiSYNseed_mask).*(IB_V_last-p.IB_NG_IBaIBdbiSYNseed_E_SYN)))))+((-(( p.IB_NG_iGABABAustin_gGABAB.*((IB_NG_iGABABAustin_g_last.^4./(IB_NG_iGABABAustin_g_last.^4 + 100))*IB_NG_iGABABAustin_netcon).*(IB_V_last-p.IB_NG_iGABABAustin_EGABAB)))))))))))))))))))/p.IB_Cm;
  IB_IBiNaF_hNaF_k1= (( (( 1./(1+exp((IB_V_last+p.IB_IBiNaF_NaF_V1)/p.IB_IBiNaF_NaF_d1)))) ./ (( p.IB_IBiNaF_NaF_c0 + p.IB_IBiNaF_NaF_c1./(1+exp((IB_V_last+p.IB_IBiNaF_NaF_V2)/p.IB_IBiNaF_NaF_d2)))))).*(1-IB_IBiNaF_hNaF_last)-(( (1-(( 1./(1+exp((IB_V_last+p.IB_IBiNaF_NaF_V1)/p.IB_IBiNaF_NaF_d1)))))./(( p.IB_IBiNaF_NaF_c0 + p.IB_IBiNaF_NaF_c1./(1+exp((IB_V_last+p.IB_IBiNaF_NaF_V2)/p.IB_IBiNaF_NaF_d2)))))).*IB_IBiNaF_hNaF_last;
  IB_IBiKDR_mKDR_k1= (( (( 1./(1+exp((-IB_V_last-p.IB_IBiKDR_KDR_V1)/p.IB_IBiKDR_KDR_d1)))) ./ (( .25+4.35*exp(-abs(IB_V_last+p.IB_IBiKDR_KDR_V2)/p.IB_IBiKDR_KDR_d2))))).*(1-IB_IBiKDR_mKDR_last)-(( (1-(( 1./(1+exp((-IB_V_last-p.IB_IBiKDR_KDR_V1)/p.IB_IBiKDR_KDR_d1)))))./(( .25+4.35*exp(-abs(IB_V_last+p.IB_IBiKDR_KDR_V2)/p.IB_IBiKDR_KDR_d2))))).*IB_IBiKDR_mKDR_last;
  IB_IBiMMich_mM_k1= ((( p.IB_IBiMMich_c_MaM.*(0.0001*p.IB_IBiMMich_Qs*(IB_V_last+30)) ./ (1-exp(-(IB_V_last+30)/9)))).*(1-IB_IBiMMich_mM_last)-(( p.IB_IBiMMich_c_MbM.*(-0.0001*p.IB_IBiMMich_Qs*(IB_V_last+30)) ./ (1-exp((IB_V_last+30)/9)))).*IB_IBiMMich_mM_last);
  IB_IBiCaH_mCaH_k1= ((( p.IB_IBiCaH_c_CaHaM.*(1.6./(1+exp(-.072*(IB_V_last-5)))))).*(1-IB_IBiCaH_mCaH_last)-(( p.IB_IBiCaH_c_CaHbM.*(.02*(IB_V_last+8.9)./(exp((IB_V_last+8.9)/5)-1)))).*IB_IBiCaH_mCaH_last)/p.IB_IBiCaH_tauCaH;
  NG_V_k1=(((-((p.NG_iPeriodicPulses_PPstim*NG_iPeriodicPulses_s2(k,:))))+((-(( p.NG_itonicPaired_stim*(t>p.NG_itonicPaired_onset & t<p.NG_itonicPaired_offset) + p.NG_itonicPaired_stim2*(t>p.NG_itonicPaired_onset2 & t<p.NG_itonicPaired_offset2))))+((p.NG_IBnoise_V_noise.*randn(1,p.NG_Npop))+((-(( p.NG_FSiNaF_gNaF.*(( 1./(1+exp((-NG_V_last-p.NG_FSiNaF_NaF_V0)/10)))).^3.*NG_FSiNaF_hNaF_last.*(NG_V_last-p.NG_FSiNaF_E_NaF))))+((-(( p.NG_FSiKDR_gKDR.*NG_FSiKDR_mKDR_last.^4.*(NG_V_last-p.NG_FSiKDR_E_KDR))))+((-(( p.NG_IBleak_g_l.*(NG_V_last-p.NG_IBleak_E_l))))+((-(( p.NG_iAhuguenard_gA * ( p.NG_iAhuguenard_iA1_fract*(NG_iAhuguenard_a1_last.^4 .* NG_iAhuguenard_b1_last) + (1-p.NG_iAhuguenard_iA1_fract)*(NG_iAhuguenard_a2_last.^4 .* NG_iAhuguenard_b2_last) ) .* (NG_V_last-p.NG_iAhuguenard_E_A))))+((-(( (NG_IB_IBaIBdbiSYNseed_gsyn.*(NG_IB_IBaIBdbiSYNseed_s_last*NG_IB_IBaIBdbiSYNseed_mask).*(NG_V_last-p.NG_IB_IBaIBdbiSYNseed_E_SYN)))))+((-(( p.NG_IB_iNMDA_gNMDA.*(( 1./(1+exp(-.062*NG_V_last)*1.5/3.57))).*(NG_IB_iNMDA_s_last*NG_IB_iNMDA_netcon).*(NG_V_last-p.NG_IB_iNMDA_ENMDA))))+((-(( (NG_NG_IBaIBdbiSYNseed_gsyn.*(NG_NG_IBaIBdbiSYNseed_s_last*NG_NG_IBaIBdbiSYNseed_mask).*(NG_V_last-p.NG_NG_IBaIBdbiSYNseed_E_SYN)))))+((-(( p.NG_NG_iGABABAustin_gGABAB.*((NG_NG_iGABABAustin_g_last.^4./(NG_NG_iGABABAustin_g_last.^4 + 100))*NG_NG_iGABABAustin_netcon).*(NG_V_last-p.NG_NG_iGABABAustin_EGABAB))))))))))))))))/p.NG_Cm;
  NG_FSiNaF_hNaF_k1= (( (( 1./(1+exp((NG_V_last+p.NG_FSiNaF_NaF_V1)/p.NG_FSiNaF_NaF_d1)))) ./ (( p.NG_FSiNaF_NaF_c0 + p.NG_FSiNaF_NaF_c1./(1+exp((NG_V_last+p.NG_FSiNaF_NaF_V2)/p.NG_FSiNaF_NaF_d2)))))).*(1-NG_FSiNaF_hNaF_last)-(( (1-(( 1./(1+exp((NG_V_last+p.NG_FSiNaF_NaF_V1)/p.NG_FSiNaF_NaF_d1)))))./(( p.NG_FSiNaF_NaF_c0 + p.NG_FSiNaF_NaF_c1./(1+exp((NG_V_last+p.NG_FSiNaF_NaF_V2)/p.NG_FSiNaF_NaF_d2)))))).*NG_FSiNaF_hNaF_last;
  NG_FSiKDR_mKDR_k1= (( (( 1./(1+exp((-NG_V_last-p.NG_FSiKDR_KDR_V1)/p.NG_FSiKDR_KDR_d1)))) ./ (( .25+4.35*exp(-abs(NG_V_last+p.NG_FSiKDR_KDR_V2)/p.NG_FSiKDR_KDR_d2))))).*(1-NG_FSiKDR_mKDR_last)-(( (1-(( 1./(1+exp((-NG_V_last-p.NG_FSiKDR_KDR_V1)/p.NG_FSiKDR_KDR_d1)))))./(( .25+4.35*exp(-abs(NG_V_last+p.NG_FSiKDR_KDR_V2)/p.NG_FSiKDR_KDR_d2))))).*NG_FSiKDR_mKDR_last;
  NG_iAhuguenard_a1_k1= p.NG_iAhuguenard_taufact * (((1./(1+exp(-(NG_V_last+60)/8.5)))) - NG_iAhuguenard_a1_last) ./ ((.37+1./(exp((NG_V_last+35.8)/19.7)+exp((NG_V_last+79.7)/-12.7))));
  NG_iAhuguenard_b1_k1= p.NG_iAhuguenard_taufact * (((1./(1+exp((NG_V_last+78)/6)))) - NG_iAhuguenard_b1_last) ./ (((1./(exp((NG_V_last+46)/5)+exp((NG_V_last+238)/(-37.5)))) .* (NG_V_last<-63) + 19 * (NG_V_last>=-63)));
  NG_iAhuguenard_a2_k1= p.NG_iAhuguenard_taufact * (((1./(1+exp(-(NG_V_last+36)/20)))) - NG_iAhuguenard_a2_last) ./ ((.37+1./(exp((NG_V_last+35.8)/19.7)+exp((NG_V_last+79.7)/-12.7))));
  NG_iAhuguenard_b2_k1= p.NG_iAhuguenard_taufact * (((1./(1+exp((NG_V_last+78)/6)))) - NG_iAhuguenard_b2_last) ./ (( (((1./(exp((NG_V_last+46)/5)+exp((NG_V_last+238)/(-37.5)))) .* (NG_V_last<-63) + 19 * (NG_V_last>=-63))) .* (NG_V_last<-73) + 60 * (NG_V_last>=-73)));
  IB_IB_IBaIBdbiSYNseed_s_k1= -IB_IB_IBaIBdbiSYNseed_s_last./p.IB_IB_IBaIBdbiSYNseed_tauDx + ((1-IB_IB_IBaIBdbiSYNseed_s_last)/p.IB_IB_IBaIBdbiSYNseed_tauRx).*(1+tanh(IB_V_last/10));
  IB_IB_iNMDA_s_k1= (( p.IB_IB_iNMDA_Tmax./(1+exp(-(IB_V_last-p.IB_IB_iNMDA_Vpp)/p.IB_IB_iNMDA_Kp)))).*(1-IB_IB_iNMDA_s_last)/p.IB_IB_iNMDA_tauNMDAr-IB_IB_iNMDA_s_last/p.IB_IB_iNMDA_tauNMDA;
  NG_IB_IBaIBdbiSYNseed_s_k1= -NG_IB_IBaIBdbiSYNseed_s_last./p.NG_IB_IBaIBdbiSYNseed_tauDx + ((1-NG_IB_IBaIBdbiSYNseed_s_last)/p.NG_IB_IBaIBdbiSYNseed_tauRx).*(1+tanh(IB_V_last/10));
  NG_IB_iNMDA_s_k1= (( p.NG_IB_iNMDA_Tmax./(1+exp(-(IB_V_last-p.NG_IB_iNMDA_Vpp)/p.NG_IB_iNMDA_Kp)))).*(1-NG_IB_iNMDA_s_last)/p.NG_IB_iNMDA_tauNMDAr-NG_IB_iNMDA_s_last/p.NG_IB_iNMDA_tauNMDA;
  NG_NG_IBaIBdbiSYNseed_s_k1= -NG_NG_IBaIBdbiSYNseed_s_last./p.NG_NG_IBaIBdbiSYNseed_tauDx + ((1-NG_NG_IBaIBdbiSYNseed_s_last)/p.NG_NG_IBaIBdbiSYNseed_tauRx).*(1+tanh(NG_V_last/10));
  NG_NG_iGABABAustin_r_k1= p.NG_NG_iGABABAustin_K1GABAB.*(( p.NG_NG_iGABABAustin_TmaxGABAB*1/2*(1 + tanh(NG_V_last./4)))).*(1-NG_NG_iGABABAustin_r_last) - p.NG_NG_iGABABAustin_K2GABAB.*NG_NG_iGABABAustin_r_last;
  NG_NG_iGABABAustin_g_k1= p.NG_NG_iGABABAustin_K3GABAB.*NG_NG_iGABABAustin_r_last - p.NG_NG_iGABABAustin_K4GABAB.*NG_NG_iGABABAustin_g_last;
  IB_NG_IBaIBdbiSYNseed_s_k1= -IB_NG_IBaIBdbiSYNseed_s_last./p.IB_NG_IBaIBdbiSYNseed_tauDx + ((1-IB_NG_IBaIBdbiSYNseed_s_last)/p.IB_NG_IBaIBdbiSYNseed_tauRx).*(1+tanh(NG_V_last/10));
  IB_NG_iGABABAustin_r_k1= p.IB_NG_iGABABAustin_K1GABAB.*(( p.IB_NG_iGABABAustin_TmaxGABAB*1/2*(1 + tanh(NG_V_last./4)))).*(1-IB_NG_iGABABAustin_r_last) - p.IB_NG_iGABABAustin_K2GABAB.*IB_NG_iGABABAustin_r_last;
  IB_NG_iGABABAustin_g_k1= p.IB_NG_iGABABAustin_K3GABAB.*IB_NG_iGABABAustin_r_last - p.IB_NG_iGABABAustin_K4GABAB.*IB_NG_iGABABAustin_g_last;
  % ------------------------------------------------------------
  % Update state variables:
  % ------------------------------------------------------------
  IB_V_last=IB_V_last+dt*IB_V_k1;
  IB_IBiNaF_hNaF_last=IB_IBiNaF_hNaF_last+dt*IB_IBiNaF_hNaF_k1;
  IB_IBiKDR_mKDR_last=IB_IBiKDR_mKDR_last+dt*IB_IBiKDR_mKDR_k1;
  IB_IBiMMich_mM_last=IB_IBiMMich_mM_last+dt*IB_IBiMMich_mM_k1;
  IB_IBiCaH_mCaH_last=IB_IBiCaH_mCaH_last+dt*IB_IBiCaH_mCaH_k1;
  NG_V_last=NG_V_last+dt*NG_V_k1;
  NG_FSiNaF_hNaF_last=NG_FSiNaF_hNaF_last+dt*NG_FSiNaF_hNaF_k1;
  NG_FSiKDR_mKDR_last=NG_FSiKDR_mKDR_last+dt*NG_FSiKDR_mKDR_k1;
  NG_iAhuguenard_a1_last=NG_iAhuguenard_a1_last+dt*NG_iAhuguenard_a1_k1;
  NG_iAhuguenard_b1_last=NG_iAhuguenard_b1_last+dt*NG_iAhuguenard_b1_k1;
  NG_iAhuguenard_a2_last=NG_iAhuguenard_a2_last+dt*NG_iAhuguenard_a2_k1;
  NG_iAhuguenard_b2_last=NG_iAhuguenard_b2_last+dt*NG_iAhuguenard_b2_k1;
  IB_IB_IBaIBdbiSYNseed_s_last=IB_IB_IBaIBdbiSYNseed_s_last+dt*IB_IB_IBaIBdbiSYNseed_s_k1;
  IB_IB_iNMDA_s_last=IB_IB_iNMDA_s_last+dt*IB_IB_iNMDA_s_k1;
  NG_IB_IBaIBdbiSYNseed_s_last=NG_IB_IBaIBdbiSYNseed_s_last+dt*NG_IB_IBaIBdbiSYNseed_s_k1;
  NG_IB_iNMDA_s_last=NG_IB_iNMDA_s_last+dt*NG_IB_iNMDA_s_k1;
  NG_NG_IBaIBdbiSYNseed_s_last=NG_NG_IBaIBdbiSYNseed_s_last+dt*NG_NG_IBaIBdbiSYNseed_s_k1;
  NG_NG_iGABABAustin_r_last=NG_NG_iGABABAustin_r_last+dt*NG_NG_iGABABAustin_r_k1;
  NG_NG_iGABABAustin_g_last=NG_NG_iGABABAustin_g_last+dt*NG_NG_iGABABAustin_g_k1;
  IB_NG_IBaIBdbiSYNseed_s_last=IB_NG_IBaIBdbiSYNseed_s_last+dt*IB_NG_IBaIBdbiSYNseed_s_k1;
  IB_NG_iGABABAustin_r_last=IB_NG_iGABABAustin_r_last+dt*IB_NG_iGABABAustin_r_k1;
  IB_NG_iGABABAustin_g_last=IB_NG_iGABABAustin_g_last+dt*IB_NG_iGABABAustin_g_k1;
if mod(k,downsample_factor)==0 % store this time point
  % ------------------------------------------------------------
  % Store state variables:
  % ------------------------------------------------------------
  IB_V(n,:)=IB_V_last;
  IB_IBiNaF_hNaF(n,:)=IB_IBiNaF_hNaF_last;
  IB_IBiKDR_mKDR(n,:)=IB_IBiKDR_mKDR_last;
  IB_IBiMMich_mM(n,:)=IB_IBiMMich_mM_last;
  IB_IBiCaH_mCaH(n,:)=IB_IBiCaH_mCaH_last;
  NG_V(n,:)=NG_V_last;
  NG_FSiNaF_hNaF(n,:)=NG_FSiNaF_hNaF_last;
  NG_FSiKDR_mKDR(n,:)=NG_FSiKDR_mKDR_last;
  NG_iAhuguenard_a1(n,:)=NG_iAhuguenard_a1_last;
  NG_iAhuguenard_b1(n,:)=NG_iAhuguenard_b1_last;
  NG_iAhuguenard_a2(n,:)=NG_iAhuguenard_a2_last;
  NG_iAhuguenard_b2(n,:)=NG_iAhuguenard_b2_last;
  IB_IB_IBaIBdbiSYNseed_s(n,:)=IB_IB_IBaIBdbiSYNseed_s_last;
  IB_IB_iNMDA_s(n,:)=IB_IB_iNMDA_s_last;
  NG_IB_IBaIBdbiSYNseed_s(n,:)=NG_IB_IBaIBdbiSYNseed_s_last;
  NG_IB_iNMDA_s(n,:)=NG_IB_iNMDA_s_last;
  NG_NG_IBaIBdbiSYNseed_s(n,:)=NG_NG_IBaIBdbiSYNseed_s_last;
  NG_NG_iGABABAustin_r(n,:)=NG_NG_iGABABAustin_r_last;
  NG_NG_iGABABAustin_g(n,:)=NG_NG_iGABABAustin_g_last;
  IB_NG_IBaIBdbiSYNseed_s(n,:)=IB_NG_IBaIBdbiSYNseed_s_last;
  IB_NG_iGABABAustin_r(n,:)=IB_NG_iGABABAustin_r_last;
  IB_NG_iGABABAustin_g(n,:)=IB_NG_iGABABAustin_g_last;
  % ------------------------------------------------------------
  % Update monitors:
  % ------------------------------------------------------------
  NG_NG_iGABABAustin_IGABAB(n,:)=p.NG_NG_iGABABAustin_gGABAB.*((NG_NG_iGABABAustin_g(n,:).^4./(NG_NG_iGABABAustin_g(n,:).^4 + 100))*NG_NG_iGABABAustin_netcon).*(NG_V(n,:)-p.NG_NG_iGABABAustin_EGABAB);
  IB_NG_iGABABAustin_IGABAB(n,:)=p.IB_NG_iGABABAustin_gGABAB.*((IB_NG_iGABABAustin_g(n,:).^4./(IB_NG_iGABABAustin_g(n,:).^4 + 100))*IB_NG_iGABABAustin_netcon).*(IB_V(n,:)-p.IB_NG_iGABABAustin_EGABAB);
  IB_IB_IBaIBdbiSYNseed_ISYN(n,:)=(IB_IB_IBaIBdbiSYNseed_gsyn.*(IB_IB_IBaIBdbiSYNseed_s(n,:)*IB_IB_IBaIBdbiSYNseed_mask).*(IB_V(n,:)-p.IB_IB_IBaIBdbiSYNseed_E_SYN));
  IB_IB_iNMDA_BMg(n,:)=1./(1+exp(-.062*IB_V(n,:))*1.5/3.57);
  IB_IB_iNMDA_INMDA(n,:)=p.IB_IB_iNMDA_gNMDA.*(( 1./(1+exp(-.062*IB_V(n,:))*1.5/3.57))).*(IB_IB_iNMDA_s(n,:)*IB_IB_iNMDA_netcon).*(IB_V(n,:)-p.IB_IB_iNMDA_ENMDA);
  IB_IB_iNMDA_NT(n,:)=p.IB_IB_iNMDA_Tmax./(1+exp(-(IB_V(n,:)-p.IB_IB_iNMDA_Vpp)/p.IB_IB_iNMDA_Kp));
  IB_NG_IBaIBdbiSYNseed_ISYN(n,:)=(IB_NG_IBaIBdbiSYNseed_gsyn.*(IB_NG_IBaIBdbiSYNseed_s(n,:)*IB_NG_IBaIBdbiSYNseed_mask).*(IB_V(n,:)-p.IB_NG_IBaIBdbiSYNseed_E_SYN));
  IB_iPeriodicPulses_Iext(n,:)=p.IB_iPeriodicPulses_PPstim*IB_iPeriodicPulses_s2(k,:);
  NG_IB_IBaIBdbiSYNseed_ISYN(n,:)=(NG_IB_IBaIBdbiSYNseed_gsyn.*(NG_IB_IBaIBdbiSYNseed_s(n,:)*NG_IB_IBaIBdbiSYNseed_mask).*(NG_V(n,:)-p.NG_IB_IBaIBdbiSYNseed_E_SYN));
  NG_IB_iNMDA_BMg(n,:)=1./(1+exp(-.062*NG_V(n,:))*1.5/3.57);
  NG_IB_iNMDA_INMDA(n,:)=p.NG_IB_iNMDA_gNMDA.*(( 1./(1+exp(-.062*NG_V(n,:))*1.5/3.57))).*(NG_IB_iNMDA_s(n,:)*NG_IB_iNMDA_netcon).*(NG_V(n,:)-p.NG_IB_iNMDA_ENMDA);
  NG_IB_iNMDA_NT(n,:)=p.NG_IB_iNMDA_Tmax./(1+exp(-(NG_V(n,:)-p.NG_IB_iNMDA_Vpp)/p.NG_IB_iNMDA_Kp));
  NG_NG_IBaIBdbiSYNseed_ISYN(n,:)=(NG_NG_IBaIBdbiSYNseed_gsyn.*(NG_NG_IBaIBdbiSYNseed_s(n,:)*NG_NG_IBaIBdbiSYNseed_mask).*(NG_V(n,:)-p.NG_NG_IBaIBdbiSYNseed_E_SYN));
  NG_iAhuguenard_IA(n,:)=p.NG_iAhuguenard_gA * ( p.NG_iAhuguenard_iA1_fract*(NG_iAhuguenard_a1(n,:).^4 .* NG_iAhuguenard_b1(n,:)) + (1-p.NG_iAhuguenard_iA1_fract)*(NG_iAhuguenard_a2(n,:).^4 .* NG_iAhuguenard_b2(n,:)) ) .* (NG_V(n,:)-p.NG_iAhuguenard_E_A);
  NG_iAhuguenard_a1inf(n,:)=1./(1+exp(-(NG_V(n,:)+60)/8.5));
  NG_iAhuguenard_a1tau(n,:)=.37+1./(exp((NG_V(n,:)+35.8)/19.7)+exp((NG_V(n,:)+79.7)/-12.7));
  NG_iAhuguenard_a2inf(n,:)=1./(1+exp(-(NG_V(n,:)+36)/20));
  NG_iAhuguenard_b1inf(n,:)=1./(1+exp((NG_V(n,:)+78)/6));
  NG_iAhuguenard_b1tau(n,:)=(1./(exp((NG_V(n,:)+46)/5)+exp((NG_V(n,:)+238)/(-37.5)))) .* (NG_V(n,:)<-63) + 19 * (NG_V(n,:)>=-63);
  NG_iAhuguenard_b2tau(n,:)=(((1./(exp((NG_V(n,:)+46)/5)+exp((NG_V(n,:)+238)/(-37.5)))) .* (NG_V(n,:)<-63) + 19 * (NG_V(n,:)>=-63))) .* (NG_V(n,:)<-73) + 60 * (NG_V(n,:)>=-73);
  NG_iPeriodicPulses_Iext(n,:)=p.NG_iPeriodicPulses_PPstim*NG_iPeriodicPulses_s2(k,:);
  n=n+1;
end
end
T=T(1:downsample_factor:ntime);
