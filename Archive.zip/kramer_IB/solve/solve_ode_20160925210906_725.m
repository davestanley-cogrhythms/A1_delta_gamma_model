function [T,FS_V,FS_FSiNaF_hNaF,FS_FSiKDR_mKDR,FS_FS_IBaIBdbiSYNseed_s,FS_FS_IBaIBdbiSYNseed_ISYN,FS_iPeriodicPulses_Tend,FS_iPeriodicPulses_s2,FS_IBleaknoisy_E_l_randomized,FS_FS_IBaIBdbiSYNseed_UB,FS_FS_IBaIBdbiSYNseed_Xpre,FS_FS_IBaIBdbiSYNseed_Xpost,FS_FS_IBaIBdbiSYNseed_mask,FS_FS_IBaIBdbiSYNseed_gsyn,FS_FS_IBaIBaiGAP_UB,FS_FS_IBaIBaiGAP_Xpre,FS_FS_IBaIBaiGAP_Xpost,FS_FS_IBaIBaiGAP_mask]=solve_ode
% ------------------------------------------------------------
% Parameters:
% ------------------------------------------------------------
p=load('params.mat','p'); p=p.p;
downsample_factor=p.downsample_factor;
dt=p.dt;
T=(p.tspan(1):dt:p.tspan(2))';
ntime=length(T);
nsamp=length(1:downsample_factor:ntime);
% ------------------------------------------------------------
% Fixed variables:
% ------------------------------------------------------------
FS_iPeriodicPulses_Tend = T(end);
FS_iPeriodicPulses_s2 = getAperiodicPulseFast(p.FS_iPeriodicPulses_PPfreq,p.FS_iPeriodicPulses_PPwidth,p.FS_iPeriodicPulses_PPshift,FS_iPeriodicPulses_Tend,p.FS_iPeriodicPulses_dt,p.FS_iPeriodicPulses_PPonset,p.FS_iPeriodicPulses_PPoffset,p.FS_iPeriodicPulses_ap_pulse_num,p.FS_iPeriodicPulses_ap_pulse_delay,p.FS_Npop,p.FS_iPeriodicPulses_kernel_type,p.FS_iPeriodicPulses_width2_rise);
FS_IBleaknoisy_E_l_randomized =  p.FS_IBleaknoisy_E_l + unifrnd(-p.FS_IBleaknoisy_E_l_std,p.FS_IBleaknoisy_E_l_std,1,p.FS_Npop);
FS_FS_IBaIBdbiSYNseed_UB =  max(p.FS_Npop,p.FS_Npop);
FS_FS_IBaIBdbiSYNseed_Xpre =  linspace(1,FS_FS_IBaIBdbiSYNseed_UB,p.FS_Npop)'*ones(1,p.FS_Npop);
FS_FS_IBaIBdbiSYNseed_Xpost =  (linspace(1,FS_FS_IBaIBdbiSYNseed_UB,p.FS_Npop)'*ones(1,p.FS_Npop))';
FS_FS_IBaIBdbiSYNseed_mask =  (abs(FS_FS_IBaIBdbiSYNseed_Xpre-FS_FS_IBaIBdbiSYNseed_Xpost)<=p.FS_FS_IBaIBdbiSYNseed_fanout);
FS_FS_IBaIBdbiSYNseed_gsyn = unifrnd(p.FS_FS_IBaIBdbiSYNseed_g_SYN-p.FS_FS_IBaIBdbiSYNseed_g_SYN_hetero,p.FS_FS_IBaIBdbiSYNseed_g_SYN+p.FS_FS_IBaIBdbiSYNseed_g_SYN_hetero,[p.FS_Npop 1])';
FS_FS_IBaIBaiGAP_UB =  max(p.FS_Npop,p.FS_Npop);
FS_FS_IBaIBaiGAP_Xpre =  linspace(1,FS_FS_IBaIBaiGAP_UB,p.FS_Npop)'*ones(1,p.FS_Npop);
FS_FS_IBaIBaiGAP_Xpost =  (linspace(1,FS_FS_IBaIBaiGAP_UB,p.FS_Npop)'*ones(1,p.FS_Npop))';
FS_FS_IBaIBaiGAP_mask =  abs(FS_FS_IBaIBaiGAP_Xpre-FS_FS_IBaIBaiGAP_Xpost)<=p.FS_FS_IBaIBaiGAP_fanout;
% ------------------------------------------------------------
% Initial conditions:
% ------------------------------------------------------------
% seed the random number generator
rng(p.random_seed);
t=0; k=1;
% STATE_VARIABLES:
FS_V = zeros(nsamp,p.FS_Npop);
  FS_V(1,:) = -65*ones(1,p.FS_Npop);
FS_FSiNaF_hNaF = zeros(nsamp,p.FS_Npop);
  FS_FSiNaF_hNaF(1,:) =  p.FS_FSiNaF_IC+p.FS_FSiNaF_IC_noise.*rand(1,p.FS_Npop);
FS_FSiKDR_mKDR = zeros(nsamp,p.FS_Npop);
  FS_FSiKDR_mKDR(1,:) =  p.FS_FSiKDR_IC+p.FS_FSiKDR_IC_noise.*rand(1,p.FS_Npop);
FS_FS_IBaIBdbiSYNseed_s = zeros(nsamp,p.FS_Npop);
  FS_FS_IBaIBdbiSYNseed_s(1,:) =  p.FS_FS_IBaIBdbiSYNseed_IC+p.FS_FS_IBaIBdbiSYNseed_IC_noise.*rand(1,p.FS_Npop)';
% MONITORS:
FS_FS_IBaIBdbiSYNseed_ISYN = zeros(nsamp,p.FS_Npop);
  FS_FS_IBaIBdbiSYNseed_ISYN(1,:)=(FS_FS_IBaIBdbiSYNseed_gsyn.*(FS_FS_IBaIBdbiSYNseed_s(1,:)*FS_FS_IBaIBdbiSYNseed_mask).*(FS_V(1,:)-p.FS_FS_IBaIBdbiSYNseed_E_SYN));
% ###########################################################
% Numerical integration:
% ###########################################################
n=2;
for k=2:ntime
  t=T(k-1);
  FS_V_k1=(((-((p.FS_iPeriodicPulses_PPstim*FS_iPeriodicPulses_s2(k,:))))+((-(( p.FS_IBitonic_stim*(t>p.FS_IBitonic_onset & t<p.FS_IBitonic_offset))))+((p.FS_IBnoise_V_noise.*randn(1,p.FS_Npop))+((-(( p.FS_FSiNaF_gNaF.*(( 1./(1+exp((-FS_V(n-1,:)-p.FS_FSiNaF_NaF_V0)/10)))).^3.*FS_FSiNaF_hNaF(n-1,:).*(FS_V(n-1,:)-p.FS_FSiNaF_E_NaF))))+((-(( p.FS_FSiKDR_gKDR.*FS_FSiKDR_mKDR(n-1,:).^4.*(FS_V(n-1,:)-p.FS_FSiKDR_E_KDR))))+((-(( p.FS_IBleaknoisy_g_l.*(FS_V(n-1,:)-FS_IBleaknoisy_E_l_randomized))))+((-(( (FS_FS_IBaIBdbiSYNseed_gsyn.*(FS_FS_IBaIBdbiSYNseed_s(n-1,:)*FS_FS_IBaIBdbiSYNseed_mask).*(FS_V(n-1,:)-p.FS_FS_IBaIBdbiSYNseed_E_SYN)))))+(((( p.FS_FS_IBaIBaiGAP_g_GAP.*sum(((FS_V(n-1,:)'*ones(1,size(FS_V(n-1,:)',1)))'-(FS_V(n-1,:)'*ones(1,size(FS_V(n-1,:)',1)))).*FS_FS_IBaIBaiGAP_mask,2)'))))))))))))/p.FS_Cm;
  FS_FSiNaF_hNaF_k1= (( (( 1./(1+exp((FS_V(n-1,:)+p.FS_FSiNaF_NaF_V1)/p.FS_FSiNaF_NaF_d1)))) ./ (( p.FS_FSiNaF_NaF_c0 + p.FS_FSiNaF_NaF_c1./(1+exp((FS_V(n-1,:)+p.FS_FSiNaF_NaF_V2)/p.FS_FSiNaF_NaF_d2)))))).*(1-FS_FSiNaF_hNaF(n-1,:))-(( (1-(( 1./(1+exp((FS_V(n-1,:)+p.FS_FSiNaF_NaF_V1)/p.FS_FSiNaF_NaF_d1)))))./(( p.FS_FSiNaF_NaF_c0 + p.FS_FSiNaF_NaF_c1./(1+exp((FS_V(n-1,:)+p.FS_FSiNaF_NaF_V2)/p.FS_FSiNaF_NaF_d2)))))).*FS_FSiNaF_hNaF(n-1,:);
  FS_FSiKDR_mKDR_k1= (( (( 1./(1+exp((-FS_V(n-1,:)-p.FS_FSiKDR_KDR_V1)/p.FS_FSiKDR_KDR_d1)))) ./ (( .25+4.35*exp(-abs(FS_V(n-1,:)+p.FS_FSiKDR_KDR_V2)/p.FS_FSiKDR_KDR_d2))))).*(1-FS_FSiKDR_mKDR(n-1,:))-(( (1-(( 1./(1+exp((-FS_V(n-1,:)-p.FS_FSiKDR_KDR_V1)/p.FS_FSiKDR_KDR_d1)))))./(( .25+4.35*exp(-abs(FS_V(n-1,:)+p.FS_FSiKDR_KDR_V2)/p.FS_FSiKDR_KDR_d2))))).*FS_FSiKDR_mKDR(n-1,:);
  FS_FS_IBaIBdbiSYNseed_s_k1= -FS_FS_IBaIBdbiSYNseed_s(n-1,:)./p.FS_FS_IBaIBdbiSYNseed_tauDx + ((1-FS_FS_IBaIBdbiSYNseed_s(n-1,:))/p.FS_FS_IBaIBdbiSYNseed_tauRx).*(1+tanh(FS_V(n-1,:)/10));
  % ------------------------------------------------------------
  % Update state variables:
  % ------------------------------------------------------------
  FS_V(n,:)=FS_V(n-1,:)+dt*FS_V_k1;
  FS_FSiNaF_hNaF(n,:)=FS_FSiNaF_hNaF(n-1,:)+dt*FS_FSiNaF_hNaF_k1;
  FS_FSiKDR_mKDR(n,:)=FS_FSiKDR_mKDR(n-1,:)+dt*FS_FSiKDR_mKDR_k1;
  FS_FS_IBaIBdbiSYNseed_s(n,:)=FS_FS_IBaIBdbiSYNseed_s(n-1,:)+dt*FS_FS_IBaIBdbiSYNseed_s_k1;
  % ------------------------------------------------------------
  % Update monitors:
  % ------------------------------------------------------------
  FS_FS_IBaIBdbiSYNseed_ISYN(n,:)=(FS_FS_IBaIBdbiSYNseed_gsyn.*(FS_FS_IBaIBdbiSYNseed_s(n,:)*FS_FS_IBaIBdbiSYNseed_mask).*(FS_V(n,:)-p.FS_FS_IBaIBdbiSYNseed_E_SYN));
  n=n+1;
end
T=T(1:downsample_factor:ntime);
