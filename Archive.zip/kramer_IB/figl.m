

figure('Position',[680     1   749   977]);